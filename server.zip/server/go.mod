module http-webserver

go 1.20

require (
	github.com/goftp/file-driver v0.0.0-20180502053751-5d604a0fc0c9
	github.com/pin/tftp v2.1.0+incompatible
)

require (
	github.com/goftp/server v0.0.0-20200708154336-f64f7c2d8a42 // indirect
	github.com/jlaffaye/ftp v0.2.0 // indirect
	github.com/stretchr/testify v1.8.4 // indirect
)
