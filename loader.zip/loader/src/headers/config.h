#pragma once

#define HTTP_SERVER "83.141.69.134"
#define HTTP_PORT 80

#define TFTP_SERVER "83.141.69.134"
