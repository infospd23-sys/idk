#pragma once

#define HTTP_SERVER "45.93.200.93"
#define HTTP_PORT 80

#define TFTP_SERVER "45.93.200.93"
