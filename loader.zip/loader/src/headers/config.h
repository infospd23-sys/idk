#pragma once

#define HTTP_SERVER "45.153.34.127"
#define HTTP_PORT 80

#define TFTP_SERVER "45.153.34.127"
